import json
from flask import Blueprint, jsonify, request, session
from vault_core import load_mod_data, save_mod_data, mod_auth, admin_only, new_id, today, get_db

MOD_ID    = "news"
blueprint = Blueprint(MOD_ID, __name__)
KINDS     = ["General", "Update", "Maintenance", "Alert"]

def _pack(items): return {"items": _sort(items)}
def _load(uid): return _sort(load_mod_data(str(uid), MOD_ID).get("items", []))
def _save(uid, items): save_mod_data(str(uid), MOD_ID, _pack(items))
def _sort(items):
    return sorted(items, key=lambda i: (1 if i.get("pinned") else 0,
        i.get("publish_date") or i.get("updated") or i.get("created") or ""), reverse=True)
def _clean(v): return str(v or "").strip()
def _kind(v): v=_clean(v); return v if v in KINDS else "General"
def _date(v):
    v=_clean(v)
    if not v: return ""
    parts=v.split("-")
    if len(parts)!=3 or any(not p.isdigit() for p in parts): return ""
    y,m,d=parts
    return v if len(y)==4 and len(m)==2 and len(d)==2 else ""

def _admin_uid():
    try:
        with get_db() as conn:
            row=conn.execute("SELECT id FROM users ORDER BY id ASC LIMIT 1").fetchone()
            return str(row[0]) if row else str(session.get("uid",""))
    except: return str(session.get("uid",""))

def _all_uids():
    try:
        with get_db() as conn:
            return [str(r[0]) for r in conn.execute("SELECT id FROM users").fetchall()]
    except: return [str(session.get("uid",""))]

def _canonical(): return _load(_admin_uid())
def _sync_all(items):
    packed=_pack(items)
    for uid in _all_uids(): save_mod_data(str(uid), MOD_ID, packed)

def _validate(r):
    title=_clean(r.get("title")); body=_clean(r.get("body"))
    if not title: return None,(jsonify({"error":"title required"}),400)
    if not body: return None,(jsonify({"error":"body required"}),400)
    return {"title":title,"body":body,"kind":_kind(r.get("kind")),"pinned":bool(r.get("pinned",False)),
            "publish_date":_date(r.get("publish_date")) or today(),"expires_on":_date(r.get("expires_on"))},None

@blueprint.route("/", methods=["GET"])
@mod_auth(MOD_ID)
def get_all():
    uid=str(session["uid"]); admin=_admin_uid()
    if uid==admin: return jsonify(_load(uid))
    canonical=_load(admin); local=_load(uid)
    if json.dumps(canonical,sort_keys=True)!=json.dumps(local,sort_keys=True):
        _save(uid,canonical)
    return jsonify(canonical)

@blueprint.route("/", methods=["POST"])
@admin_only
def add():
    r=request.get_json() or {}; rec,err=_validate(r)
    if err: return err
    rec.update({"id":new_id(),"created":today(),"updated":today(),
                "author":_clean(session.get("username")) or "admin"})
    items=_canonical(); items.append(rec); _sync_all(_sort(items))
    return jsonify(rec),201

@blueprint.route("/<rid>", methods=["PUT"])
@admin_only
def update(rid):
    r=request.get_json() or {}; items=_canonical()
    for item in items:
        if item.get("id")==rid:
            payload,err=_validate({**item,**r})
            if err: return err
            item.update(payload); item["updated"]=today()
            item["author"]=_clean(session.get("username")) or item.get("author","admin")
            _sync_all(_sort(items)); return jsonify(item)
    return jsonify({"error":"not found"}),404

@blueprint.route("/<rid>", methods=["DELETE"])
@admin_only
def delete(rid):
    _sync_all([i for i in _canonical() if i.get("id")!=rid])
    return jsonify({"ok":True})
