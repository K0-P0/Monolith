(function(){'use strict';
let _savTab='goal';

(function bp(){
    if(document.getElementById('sav-grid'))return;
    const d=document.createElement('div');d.id='page-savings';d.className='page';
    d.innerHTML=`
    <div style="display:flex;background:var(--bg2);border:1px solid var(--line2);border-radius:var(--r);padding:3px;margin-bottom:0">
        <button class="sav-stab" id="st-goal" onclick="sav_tab('goal')" style="flex:1;padding:8px 4px;border:none;background:var(--amber);color:#000;cursor:pointer;font-family:var(--fd);font-size:12px;font-weight:700;border-radius:calc(var(--r) - 1px);transition:all .15s;min-height:36px">💰 Goals</button>
        <button class="sav-stab" id="st-roth_ira" onclick="sav_tab('roth_ira')" style="flex:1;padding:8px 4px;border:none;background:transparent;color:var(--ghost);cursor:pointer;font-family:var(--fd);font-size:12px;font-weight:700;border-radius:calc(var(--r) - 1px);transition:all .15s;min-height:36px">📈 Roth IRA</button>
        <button class="sav-stab" id="st-401k" onclick="sav_tab('401k')" style="flex:1;padding:8px 4px;border:none;background:transparent;color:var(--ghost);cursor:pointer;font-family:var(--fd);font-size:12px;font-weight:700;border-radius:calc(var(--r) - 1px);transition:all .15s;min-height:36px">🏛️ 401k</button>
    </div>
    <div class="card">
        <div class="card-hd"><span class="card-title">Add / Edit Goal</span></div>
        <input type="hidden" id="sav-eid">
        <div class="fg-grid">
            <div class="fg"><label>Name</label><input id="sav-name" type="text" placeholder="Emergency Fund, Car, etc."></div>
            <div class="fg"><label>Target $</label><input id="sav-tgt" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Current Balance $</label><input id="sav-cur" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Monthly Contrib $</label><input id="sav-mc" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg" id="sav-fg-em" style="display:none"><label>Employer Match %</label><input id="sav-em" type="number" placeholder="4" step="0.5" min="0" max="100"></div>
            <div class="fg" id="sav-fg-al" style="display:none"><label>Annual Limit $</label><input id="sav-al" type="number" placeholder="7000" step="100" min="0"></div>
            <div class="fg" id="sav-fg-ytd" style="display:none"><label>YTD Contributions $</label><input id="sav-ytd" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Target Date</label><div class="dw"><input id="sav-td" type="date"><button class="cal-btn" onclick="dp('sav-td')">📅</button></div></div>
            <div class="fg"><label>Notes</label><input id="sav-notes" type="text" placeholder="Optional"></div>
            <div class="fg full"><div class="fa">
                <button class="btn btn-g btn-sm" onclick="sav_clear()">Clear</button>
                <button class="btn btn-p btn-sm" onclick="sav_save()">Save Goal</button>
            </div></div>
        </div>
    </div>
    <div class="stat-row" id="sav-stats"></div>
    <div id="sav-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(270px,1fr));gap:12px"></div>`;
    const pg=document.getElementById('page-savings');
    if(pg&&!document.getElementById('sav-grid'))pg.innerHTML=d.innerHTML;
    else if(!pg)document.getElementById('content').appendChild(d);
})();

window.dashWidget_savings=function(){
    const items=DB.savings||[];
    const totalSaved=items.reduce((s,x)=>s+parseFloat(x.current||0),0);
    const totalTarget=items.reduce((s,x)=>s+parseFloat(x.target||0),0);
    const pct=totalTarget>0?Math.round((totalSaved/totalTarget)*100):0;
    const barC=pct>=75?'var(--green)':pct>=40?'var(--blue)':'var(--amber)';
    return`<div class="card" onclick="navigate('savings')" style="cursor:pointer">
        <div class="card-hd"><span class="card-title">🏦 Savings</span><span class="badge bg">${items.length} goals</span></div>
        <div class="stat-row" style="grid-template-columns:1fr 1fr;gap:8px">
            <div class="stat"><div class="stat-label">Total Saved</div><div class="stat-val g">${fmtK(totalSaved)}</div><div class="stat-bar g"></div></div>
            <div class="stat"><div class="stat-label">Progress</div><div class="stat-val b">${pct}%</div><div class="stat-bar b"></div></div>
        </div>
        ${totalTarget>0?`<div class="bar-w" style="height:6px;margin-top:8px"><div class="bar-f" style="width:${pct}%;background:${barC}"></div></div>`:''}
    </div>`;
};

window.render_savings=async function(){ sav_render(); };

window.sav_tab=function(t){
    _savTab=t;
    document.querySelectorAll('.sav-stab').forEach(b=>{
        const active=b.id===`st-${t}`;
        b.style.background=active?'var(--amber)':'transparent';
        b.style.color=active?'#000':'var(--ghost)';
    });
    document.getElementById('sav-fg-em').style.display=t==='401k'?'':'none';
    const isRet=t==='roth_ira'||t==='401k';
    document.getElementById('sav-fg-al').style.display=isRet?'':'none';
    document.getElementById('sav-fg-ytd').style.display=isRet?'':'none';
    const al=document.getElementById('sav-al');
    if(al&&!al.value){if(t==='roth_ira')al.value='7000';if(t==='401k')al.value='23500';}
    sav_clear();sav_render();
};

window.sav_save=async function(){
    const id=document.getElementById('sav-eid').value;
    const body={
        name:document.getElementById('sav-name').value.trim(),
        savings_type:_savTab,
        target:parseFloat(document.getElementById('sav-tgt').value)||0,
        current:parseFloat(document.getElementById('sav-cur').value)||0,
        monthly_contrib:parseFloat(document.getElementById('sav-mc').value)||0,
        employer_match_pct:parseFloat(document.getElementById('sav-em').value)||0,
        annual_limit:parseFloat(document.getElementById('sav-al').value)||0,
        ytd_contrib:parseFloat(document.getElementById('sav-ytd').value)||0,
        target_date:document.getElementById('sav-td').value,
        notes:document.getElementById('sav-notes').value.trim(),
    };
    if(!body.name||!body.target){toast('Name and target required','wn');return;}
    try{
        if(id)await api('PUT',`/api/mod/savings/${id}`,body);
        else await api('POST','/api/mod/savings/',body);
        toast(id?'Updated':'Saved','ok');sav_clear();
        await loadMod('savings');sav_render();
    }catch(e){toast(e.message,'er');}
};

window.sav_edit=function(id){
    const gx=(DB.savings||[]).find(x=>x.id===id);if(!gx)return;
    _savTab=gx.savings_type||'goal';sav_tab(_savTab);
    document.getElementById('sav-eid').value=gx.id;
    document.getElementById('sav-name').value=gx.name;
    document.getElementById('sav-tgt').value=gx.target;
    document.getElementById('sav-cur').value=gx.current;
    document.getElementById('sav-mc').value=gx.monthly_contrib||'';
    document.getElementById('sav-em').value=gx.employer_match_pct||'';
    document.getElementById('sav-al').value=gx.annual_limit||'';
    document.getElementById('sav-ytd').value=gx.ytd_contrib||'';
    document.getElementById('sav-td').value=gx.target_date||'';
    document.getElementById('sav-notes').value=gx.notes||'';
    document.getElementById('sav-name').scrollIntoView({behavior:'smooth'});
};

window.sav_del=async function(id){
    if(!confirm('Delete this goal?'))return;
    try{
        await api('DELETE',`/api/mod/savings/${id}`);
        toast('Deleted','ok');await loadMod('savings');sav_render();
    }catch(e){toast(e.message,'er');}
};

window.sav_clear=function(){
    ['sav-eid','sav-name','sav-tgt','sav-cur','sav-mc','sav-em','sav-al','sav-ytd','sav-td','sav-notes'].forEach(id=>{
        const el=document.getElementById(id);if(el)el.value='';
    });
};

window.sav_openatb=function(id){
    const gx=(DB.savings||[]).find(x=>x.id===id);if(!gx)return;
    window._atbSign=1;
    const showYtd=(gx.savings_type==='roth_ira'||gx.savings_type==='401k')&&gx.annual_limit>0;
    openModal(`Add to Balance — ${gx.name}`,`
        <div style="background:var(--bg2);border-radius:var(--r);padding:12px 14px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
            <div><div style="font-family:var(--fm);font-size:9px;text-transform:uppercase;letter-spacing:2px;color:var(--muted)">Current Balance</div>
            <div style="font-family:var(--fm);font-size:20px;font-weight:600;color:var(--bright)">${fmt(gx.current)}</div></div>
        </div>
        <div style="display:flex;gap:3px;margin-bottom:12px">
            <button class="btn btn-ok" id="sav-atb-a" onclick="sav_atbsign(1,${gx.current})" style="flex:1;font-size:18px;font-weight:700">+ Add</button>
            <button class="btn btn-g" id="sav-atb-s" onclick="sav_atbsign(-1,${gx.current})" style="flex:1;font-size:18px;font-weight:700">− Subtract</button>
        </div>
        <div class="fg" style="margin-bottom:10px"><label>Amount $</label>
            <input id="sav-atb-v" type="number" placeholder="0.00" step="0.01" min="0"
                   oninput="sav_atbupd(${gx.current})"
                   style="height:52px;font-size:18px;font-family:var(--fm)">
        </div>
        ${showYtd?`<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
            <input type="checkbox" id="sav-atb-ytd" style="width:auto;height:auto;margin:0">
            <label for="sav-atb-ytd" style="font-size:12px;color:var(--text);text-transform:none;letter-spacing:0;font-weight:400;cursor:pointer">Count toward YTD contributions</label>
        </div>`:''}
        <div style="background:var(--bg3);border:1px solid var(--line2);border-radius:var(--r);padding:10px 14px;display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
            <span style="font-family:var(--fm);font-size:9px;text-transform:uppercase;letter-spacing:2px;color:var(--muted)">New Balance</span>
            <div id="sav-atb-nb" style="font-family:var(--fm);font-size:18px;font-weight:600;color:var(--bright)">${fmt(gx.current)}</div>
        </div>
        <div class="fa">
            <button class="btn btn-g btn-sm" onclick="closeModal()">Cancel</button>
            <button class="btn btn-ok" onclick="sav_submitatb('${id}',${gx.current})">Update Balance ✓</button>
        </div>`);
};

window.sav_atbsign=function(s,cur){
    window._atbSign=s;
    document.getElementById('sav-atb-a').className=`btn ${s===1?'btn-ok':'btn-g'}`;
    document.getElementById('sav-atb-s').className=`btn ${s===-1?'btn-d':'btn-g'}`;
    sav_atbupd(cur);
};

window.sav_atbupd=function(cur){
    const amt=parseFloat(document.getElementById('sav-atb-v')?.value)||0;
    const nb=Math.max(0,cur+(window._atbSign||1)*amt);
    const el=document.getElementById('sav-atb-nb');
    if(el){el.textContent=fmt(nb);el.style.color=nb>=cur?'var(--green)':'var(--red)';}
};

window.sav_submitatb=async function(id,cur){
    const amt=parseFloat(document.getElementById('sav-atb-v')?.value)||0;
    if(amt<=0){toast('Enter an amount','wn');return;}
    try{
        await api('POST',`/api/mod/savings/${id}/add`,{amount:(window._atbSign||1)*amt,add_ytd:document.getElementById('sav-atb-ytd')?.checked||false});
        toast('Balance updated','ok');closeModal();
        await loadMod('savings');sav_render();
    }catch(e){toast(e.message,'er');}
};

function sav_render(){
    const items=(DB.savings||[]).filter(x=>(x.savings_type||'goal')===_savTab);
    const ts=items.reduce((s,x)=>s+parseFloat(x.current||0),0);
    const tt=items.reduce((s,x)=>s+parseFloat(x.target||0),0);
    const tc=items.reduce((s,x)=>s+parseFloat(x.monthly_contrib||0),0);
    const statsEl=document.getElementById('sav-stats');
    if(statsEl)statsEl.innerHTML=`
        <div class="stat"><div class="stat-label">Total Saved</div><div class="stat-val g">${fmtK(ts)}</div><div class="stat-bar g"></div></div>
        <div class="stat"><div class="stat-label">Total Target</div><div class="stat-val">${fmtK(tt)}</div><div class="stat-bar"></div></div>
        <div class="stat"><div class="stat-label">Monthly Contrib</div><div class="stat-val b">${fmtK(tc)}</div><div class="stat-bar b"></div></div>`;
    const grid=document.getElementById('sav-grid');if(!grid)return;
    if(!items.length){
        const icons={goal:'💰',roth_ira:'📈','401k':'🏛️'};
        grid.innerHTML=`<div class="card" style="grid-column:1/-1"><div class="empty"><div class="ei">${icons[_savTab]||'💰'}</div><p class="ep">No ${_savTab.replace('_',' ')} goals yet. Add one above.</p></div></div>`;
        return;
    }
    grid.innerHTML=items.map(gx=>{
        const pct=Math.min(100,Math.round(parseFloat(gx.current)/parseFloat(gx.target)*100));
        const rem=Math.max(0,parseFloat(gx.target)-parseFloat(gx.current));
        const mc=parseFloat(gx.monthly_contrib||0);
        const barC=pct>=100?'var(--green)':pct>=60?'var(--blue)':'var(--amber)';
        const moL=mc>0?Math.ceil(rem/mc):null;
        let eta='';
        if(parseFloat(gx.current)>=parseFloat(gx.target))eta='✅ Done!';
        else if(moL!==null){const ed=new Date();ed.setMonth(ed.getMonth()+moL);eta=`ETA: ${ed.toLocaleString('en-US',{month:'short',year:'numeric'})}`;}
        return`<div class="card">
            <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px;gap:8px">
                <div><div style="font-weight:700;font-size:14px;color:var(--bright)">${gx.name}</div>
                ${gx.notes?`<div style="font-size:11px;color:var(--dim);margin-top:2px">${gx.notes}</div>`:''}
                </div>
                <div class="ra">
                    <button class="btn btn-ok btn-xs" onclick="sav_openatb('${gx.id}')">+ Balance</button>
                    <button class="btn btn-g btn-xs" onclick="sav_edit('${gx.id}')">✏</button>
                    <button class="btn btn-d btn-xs" onclick="sav_del('${gx.id}')">🗑</button>
                </div>
            </div>
            <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:8px">
                <div><div style="font-family:var(--fm);font-size:8px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:2px">Saved</div>
                <div style="font-family:var(--fm);font-size:15px;font-weight:600;color:var(--green)">${fmt(gx.current)}</div></div>
                <div><div style="font-family:var(--fm);font-size:8px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:2px">Target</div>
                <div style="font-family:var(--fm);font-size:15px;font-weight:600">${fmt(gx.target)}</div></div>
                <div><div style="font-family:var(--fm);font-size:8px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:2px">Remaining</div>
                <div style="font-family:var(--fm);font-size:15px;font-weight:600;color:var(--amber)">${fmt(rem)}</div></div>
                ${mc>0?`<div><div style="font-family:var(--fm);font-size:8px;text-transform:uppercase;letter-spacing:1.5px;color:var(--muted);margin-bottom:2px">Monthly</div>
                <div style="font-family:var(--fm);font-size:15px;font-weight:600;color:var(--blue)">${fmt(mc)}</div></div>`:''}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--muted);font-family:var(--fm);margin-bottom:3px">
                <span>${pct}%</span><span>${eta}</span>
            </div>
            <div class="bar-w" style="height:7px"><div class="bar-f" style="width:${pct}%;background:${barC}"></div></div>
            ${gx.target_date?`<div style="font-size:10px;color:var(--dim);font-family:var(--fm);margin-top:5px">Target: ${fd(gx.target_date)}</div>`:''}
        </div>`;
    }).join('');
}
})();
