(function(){'use strict';

(function bp(){
    if(document.getElementById('bud-list'))return;
    const d=document.createElement('div');d.id='page-budget';d.className='page';
    d.innerHTML=`
    <div class="card">
        <div class="card-hd"><span class="card-title">Set Budget Limit</span></div>
        <div class="fg-grid">
            <div class="fg"><label>Category</label><select id="bud-cat">
                <option>Food &amp; Dining</option><option>Transport / Gas</option>
                <option>Shopping</option><option>Entertainment</option>
                <option>Health / Medical</option><option>Personal Care</option>
                <option>Home</option><option>Tech / Electronics</option>
                <option>Tools / Hardware</option><option>Pet Care</option>
                <option>Housing</option><option>Utilities</option>
                <option>Insurance</option><option>Other</option>
            </select></div>
            <div class="fg"><label>Monthly Limit $</label><input id="bud-lim" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg full"><div class="fa"><button class="btn btn-p btn-sm" onclick="bud_save()">Set Limit</button></div></div>
        </div>
    </div>
    <div class="card">
        <div class="card-hd"><span class="card-title">Budget vs Actual (This Month)</span></div>
        <div id="bud-list"></div>
    </div>`;
    const pg=document.getElementById('page-budget');
    if(pg&&!document.getElementById('bud-list'))pg.innerHTML=d.innerHTML;
    else if(!pg)document.getElementById('content').appendChild(d);
})();

window.dashWidget_budget=function(){
    const mk=cmk();
    const budgets=DB.budget||[];
    const exps=(DB.expenses||[]).filter(e=>e.date?.startsWith(mk));
    if(!budgets.length)return'';
    let mostUsed={pct:-1,category:'',spent:0,limit:0};
    budgets.forEach(b=>{
        const spent=exps.filter(e=>e.category===b.category).reduce((s,e)=>s+parseFloat(e.amount),0);
        const pct=Math.round((spent/b.limit)*100);
        if(pct>mostUsed.pct)mostUsed={...b,spent,pct};
    });
    const barC=mostUsed.pct>=100?'var(--red)':mostUsed.pct>=80?'var(--amber)':'var(--green)';
    return`<div class="card" onclick="navigate('budget')" style="cursor:pointer">
        <div class="card-hd"><span class="card-title">🎯 Budget Watch</span></div>
        <div style="font-size:12px;margin-bottom:4px"><b>${mostUsed.category}</b>: ${mostUsed.pct}% used</div>
        <div class="bar-w" style="height:8px"><div class="bar-f" style="width:${Math.min(100,mostUsed.pct)}%;background:${barC}"></div></div>
        <div style="font-size:10px;color:var(--dim);margin-top:6px">${fmt(mostUsed.spent)} of ${fmt(mostUsed.limit)}</div>
    </div>`;
};

window.render_budget=async function(){
    await loadMod('expenses');
    bud_render();
};

window.bud_save=async function(){
    const body={category:document.getElementById('bud-cat').value,limit:parseFloat(document.getElementById('bud-lim').value)};
    if(!body.limit){toast('Enter a limit','wn');return;}
    try{
        await api('POST','/api/mod/budget/',body);
        toast('Limit set','ok');
        document.getElementById('bud-lim').value='';
        await loadMod('budget');bud_render();
    }catch(e){toast(e.message,'er');}
};

window.bud_del=async function(id){
    if(!confirm('Remove this budget limit?'))return;
    try{
        await api('DELETE',`/api/mod/budget/${id}`);
        toast('Removed','ok');
        await loadMod('budget');bud_render();
    }catch(e){toast(e.message,'er');}
};

function bud_render(){
    const mk=cmk();
    const exps=(DB.expenses||[]).filter(e=>e.date?.startsWith(mk));
    const list=document.getElementById('bud-list');
    const items=DB.budget||[];
    if(!items.length){list.innerHTML=`<div class="empty"><div class="ei">🎯</div><p class="ep">No budget limits yet.</p></div>`;return;}
    list.innerHTML=items.map(b=>{
        const spent=exps.filter(e=>e.category===b.category).reduce((s,e)=>s+parseFloat(e.amount),0);
        const pct=Math.min(100,Math.round((spent/b.limit)*100));
        const over=spent>b.limit;
        const barC=over?'var(--red)':pct>=80?'var(--amber)':'var(--green)';
        return`<div style="padding:12px 0;border-bottom:1px solid var(--line)">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
                <div style="font-weight:600">${b.category}</div>
                <div class="flex-c gap8">
                    <span class="mono ${over?'r':'g'}">${fmt(spent)}</span>
                    <span class="dm">/ ${fmt(b.limit)}</span>
                    <button class="btn btn-d btn-xs" onclick="bud_del('${b.id}')">✕</button>
                </div>
            </div>
            <div class="bar-w" style="height:6px"><div class="bar-f" style="width:${pct}%;background:${barC}"></div></div>
            <div style="font-size:10px;color:var(--muted);margin-top:4px">${pct}% of budget used</div>
        </div>`;
    }).join('');
}
})();
