from flask import Blueprint, jsonify, request, session
from vault_core import admin_only, load_security, save_security, log_security, get_db

def _backup_remaining(sec):
    import sys
    srv = sys.modules.get("__main__")
    if srv and hasattr(srv, "_backup_remaining"):
        return srv._backup_remaining(sec)
    return sum(1 for c in sec.get("backup_codes", []) if not c.get("used"))

MOD_ID    = "admin"
blueprint = Blueprint(MOD_ID, __name__)

@blueprint.route("/", methods=["GET"])
@admin_only
def list_users():
    with get_db() as db:
        users = [dict(u) for u in
                 db.execute("SELECT id,username,is_admin,created FROM users").fetchall()]
    for u in users:
        sec = load_security(u["id"])
        u["totp_configured"]        = bool(sec.get("totp_secret"))
        u["totp_setup_date"]        = sec.get("totp_setup_date")
        u["backup_codes_remaining"] = _backup_remaining(sec)
    return jsonify(users)

@blueprint.route("/<uid>/reset-totp", methods=["DELETE"])
@admin_only
def reset_totp(uid):
    if uid == session["uid"]:
        return jsonify({"error": "Use Profile to manage your own 2FA"}), 400
    with get_db() as db:
        u = db.execute("SELECT username FROM users WHERE id=?", (uid,)).fetchone()
    if not u:
        return jsonify({"error": "User not found"}), 404
    sec = load_security(uid)
    for k in ("totp_secret", "totp_setup_date", "backup_codes", "backup_codes_created"):
        sec.pop(k, None)
    if sec:
        save_security(uid, sec)
    else:
        from vault_core import delete_security
        delete_security(uid)
    log_security("totp_reset_by_admin", uid=uid, username=u["username"], detail=f"by_admin={session['uid']}")
    return jsonify({
        "ok":      True,
        "message": (f"2FA reset for {u['username']}. "
                    "They will be required to set up a new authenticator on next login. "
                    "Their financial data is not affected."),
    })
