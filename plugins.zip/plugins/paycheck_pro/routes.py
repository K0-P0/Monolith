from vault_core import load_mod_data, save_mod_data, mod_auth, new_id, today
from flask import Blueprint, jsonify, request, session

MOD_ID = "paycheck_pro"
blueprint = Blueprint(MOD_ID, __name__)

PERIODS = {"weekly": 52, "biweekly": 26, "semimonthly": 24, "monthly": 12, "annual": 1}

def _calc(r):
    t = r.get("income_type", "hourly")
    freq = r.get("frequency", "biweekly")
    if t == "hourly":
        gross = float(r.get("hourly_rate", 0)) * float(r.get("hours_per_period", 0))
    elif t == "salary":
        gross = float(r.get("annual_salary", 0)) / PERIODS.get(freq, 26)
    else:
        net = float(r.get("net_direct", 0))
        return {"gross": net, "k401_amount": 0.0, "tax_amount": 0.0, "net": round(net, 2)}
    k401t = r.get("k401_type", "percent")
    k401v = float(r.get("k401_value", 0))
    k401a = max(0.0, gross * k401v / 100 if k401t == "percent" else min(k401v, gross))
    taxa  = max(0.0, (gross - k401a) * float(r.get("tax_rate", 0)) / 100)
    return {
        "gross":       round(gross, 2),
        "k401_amount": round(k401a, 2),
        "tax_amount":  round(taxa, 2),
        "net":         round(max(0, gross - k401a - taxa), 2),
    }

def _load(uid):    return load_mod_data(uid, MOD_ID)
def _save(uid, d): save_mod_data(uid, MOD_ID, d)
def _sources(uid): return _load(uid).get("sources", [])
def _history(uid): return _load(uid).get("history", [])

@blueprint.route("/", methods=["GET"])
@mod_auth(MOD_ID)
def get_all():
    return jsonify(_sources(session['uid']))

@blueprint.route("/", methods=["POST"])
@mod_auth(MOD_ID)
def add():
    r = request.get_json(); uid = session['uid']
    name = r.get("name", "").strip()
    if not name: return jsonify({"error": "Name required"}), 400
    rec = {
        "id": new_id(), "name": name,
        "income_type":      r.get("income_type", "hourly"),
        "hourly_rate":      float(r.get("hourly_rate", 0)),
        "hours_per_period": float(r.get("hours_per_period", 0)),
        "annual_salary":    float(r.get("annual_salary", 0)),
        "k401_type":        r.get("k401_type", "percent"),
        "k401_value":       float(r.get("k401_value", 0)),
        "tax_rate":         float(r.get("tax_rate", 0)),
        "net_direct":       float(r.get("net_direct", 0)),
        "frequency":        r.get("frequency", "biweekly"),
        "last_paid":        r.get("last_paid", ""),
        "notes":            r.get("notes", "").strip(),
        "created":          today(),
        **_calc(r),
    }
    sources = _sources(uid); sources.append(rec)
    d = _load(uid); d["sources"] = sources; _save(uid, d)
    return jsonify(rec), 201

@blueprint.route("/<rid>", methods=["PUT"])
@mod_auth(MOD_ID)
def update_source(rid):
    r = request.get_json(); uid = session['uid']
    d = _load(uid); sources = d.get("sources", [])
    for src in sources:
        if src["id"] == rid:
            for k in ["name","income_type","k401_type","frequency","last_paid","notes"]:
                if k in r: src[k] = r[k]
            for k in ["hourly_rate","hours_per_period","annual_salary","k401_value","tax_rate","net_direct"]:
                if k in r: src[k] = float(r[k])
            src.update(_calc(src))
            d["sources"] = sources; _save(uid, d)
            return jsonify(src)
    return jsonify({"error": "not found"}), 404

@blueprint.route("/<rid>", methods=["DELETE"])
@mod_auth(MOD_ID)
def delete_source(rid):
    uid = session['uid']
    d = _load(uid)
    d["sources"] = [s for s in d.get("sources", []) if s["id"] != rid]
    _save(uid, d)
    return jsonify({"ok": True})

@blueprint.route("/history", methods=["GET"])
@mod_auth(MOD_ID)
def get_history():
    return jsonify(_history(session['uid']))

@blueprint.route("/history", methods=["POST"])
@mod_auth(MOD_ID)
def log_paycheck():
    r = request.get_json(); uid = session['uid']
    actual = float(r.get("actual", 0))
    if actual <= 0: return jsonify({"error": "Actual amount required"}), 400
    rec = {
        "id":          new_id(),
        "source_id":   r.get("source_id", ""),
        "source_name": r.get("source_name", "Manual Entry"),
        "date":        r.get("date", today()),
        "expected":    round(float(r.get("expected", 0)), 2),
        "actual":      round(actual, 2),
        "difference":  round(actual - float(r.get("expected", 0)), 2),
        "notes":       r.get("notes", "").strip(),
        "created":     today(),
    }
    history = _history(uid); history.append(rec)
    d = _load(uid); d["history"] = history; _save(uid, d)
    return jsonify(rec), 201

@blueprint.route("/history/<rid>", methods=["DELETE"])
@mod_auth(MOD_ID)
def delete_history(rid):
    uid = session['uid']
    d = _load(uid)
    d["history"] = [h for h in d.get("history", []) if h["id"] != rid]
    _save(uid, d)
    return jsonify({"ok": True})
