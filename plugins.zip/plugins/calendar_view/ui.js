(function(){'use strict';
let _calY,_calM;
(()=>{const d=new Date();_calY=d.getFullYear();_calM=d.getMonth();})();

(function bp(){
    if(document.getElementById('cal-grid')&&document.getElementById('cal-grid').children.length>0)return;
    const d=document.createElement('div');d.id='page-calendar_view';d.className='page';
    d.innerHTML=`
    <div class="card">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
            <button class="btn btn-g btn-sm" onclick="cal_prev()">&#x2190; Prev</button>
            <div id="cal-ml" style="font-size:15px;font-weight:700;color:var(--bright);flex:1;text-align:center">-</div>
            <button class="btn btn-g btn-sm" onclick="cal_next()">Next &#x2192;</button>
        </div>
        <div style="display:flex;gap:10px;margin-bottom:10px;flex-wrap:wrap">
            <div style="display:flex;align-items:center;gap:5px;font-size:11px"><span style="width:9px;height:9px;border-radius:2px;background:rgba(56,200,114,.2);border:1px solid var(--green);display:inline-block"></span><span class="dm">Payday</span></div>
            <div style="display:flex;align-items:center;gap:5px;font-size:11px"><span style="width:9px;height:9px;border-radius:2px;background:rgba(224,82,82,.2);border:1px solid var(--red);display:inline-block"></span><span class="dm">Subscription</span></div>
            <div style="display:flex;align-items:center;gap:5px;font-size:11px"><span style="width:9px;height:9px;border-radius:2px;background:rgba(240,160,0,.15);border:1px solid var(--amber);display:inline-block"></span><span class="dm">Bill</span></div>
        </div>
        <div id="cal-grid" style="display:grid;grid-template-columns:repeat(7,1fr);gap:2px">
            ${['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(day=>`<div style="text-align:center;font-family:var(--fm);font-size:9px;text-transform:uppercase;color:var(--muted);padding:4px">${day}</div>`).join('')}
        </div>
    </div>
    <div class="card">
        <div class="card-hd"><span class="card-title">Charge Timeline</span></div>
        <div id="cal-tl"></div>
    </div>`;
    const pg=document.getElementById('page-calendar_view');
    if(pg&&!document.getElementById('cal-tl'))pg.innerHTML=d.innerHTML;
    else if(!pg)document.getElementById('content').appendChild(d);
    if(!document.getElementById('cal-css')){
        const s=document.createElement('style');s.id='cal-css';
        s.textContent=`.cal-cell{background:var(--bg2);border:1px solid var(--line);border-radius:var(--r);padding:4px;min-height:56px}.cal-cell.td{border-color:var(--amber)!important}.cal-cell.om{opacity:.22}.cal-dn{font-family:var(--fm);font-size:10px;color:var(--dim);margin-bottom:2px}.cal-ev{font-size:8px;padding:2px 3px;border-radius:2px;margin-bottom:1px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:var(--fm)}.cal-ev.sub{background:rgba(224,82,82,.2);color:var(--red)}.cal-ev.bill{background:rgba(240,160,0,.15);color:var(--amber)}.cal-ev.income{background:rgba(56,200,114,.15);color:var(--green)}`;
        document.head.appendChild(s);
    }
})();

window.render_calendar_view=async function(){ cal_draw(); };
window.cal_prev=function(){_calM--;if(_calM<0){_calM=11;_calY--;}cal_draw();};
window.cal_next=function(){_calM++;if(_calM>11){_calM=0;_calY++;}cal_draw();};

async function cal_draw(){
    const calData=DB.calendar_view||{};
    const mn=['January','February','March','April','May','June','July','August','September','October','November','December'];
    const ml=document.getElementById('cal-ml');if(ml)ml.textContent=`${mn[_calM]} ${_calY}`;
    const grid=document.getElementById('cal-grid');if(!grid)return;
    while(grid.children.length>7)grid.removeChild(grid.lastChild);
    const fdow=new Date(_calY,_calM,1).getDay(),dim=new Date(_calY,_calM+1,0).getDate(),today=new Date();
    const events={};
    const addEv=(d,e)=>{if(!events[d])events[d]=[];events[d].push(e);};
    (calData.subscriptions||[]).filter(s=>s.active&&s.next_due).forEach(s=>{
        const d=new Date(s.next_due+'T00:00:00');
        if(d.getFullYear()===_calY&&d.getMonth()===_calM)addEv(d.getDate(),{name:s.name,type:'sub',amount:s.amount});
    });
    (calData.bills||[]).forEach(b=>{
        if(b.due_day>=1&&b.due_day<=dim)addEv(b.due_day,{name:b.name,type:'bill',amount:b.amount});
    });
    (calData.sources||[]).forEach(i=>{
        if(!i.last_paid)return;
        const gap={weekly:7,biweekly:14,semimonthly:15,monthly:30,annual:365}[i.frequency]||14;
        let d=new Date(i.last_paid+'T00:00:00');
        const start=new Date(_calY,_calM,1);
        while(d<start)d.setDate(d.getDate()+gap);
        while(d.getMonth()===_calM&&d.getFullYear()===_calY){
            addEv(d.getDate(),{name:i.name,type:'income',amount:parseFloat(i.net||0)});
            d.setDate(d.getDate()+gap);
        }
    });
    for(let i=0;i<fdow;i++){const c=document.createElement('div');c.className='cal-cell om';c.innerHTML='<div class="cal-dn"></div>';grid.appendChild(c);}
    for(let day=1;day<=dim;day++){
        const c=document.createElement('div');
        const isTd=today.getFullYear()===_calY&&today.getMonth()===_calM&&today.getDate()===day;
        c.className='cal-cell'+(isTd?' td':'');
        let h=`<div class="cal-dn">${day}</div>`;
        (events[day]||[]).slice(0,3).forEach(ev=>{h+=`<div class="cal-ev ${ev.type}" title="${ev.name}">${ev.name}</div>`;});
        if((events[day]||[]).length>3)h+=`<div style="font-size:8px;color:var(--muted);font-family:var(--fm)">+${events[day].length-3}</div>`;
        c.innerHTML=h;grid.appendChild(c);
    }
    const tl=[];
    (calData.subscriptions||[]).filter(s=>s.active&&s.next_due).forEach(s=>{
        const d=new Date(s.next_due+'T00:00:00');
        if(d.getFullYear()===_calY&&d.getMonth()===_calM)tl.push({day:d.getDate(),name:s.name,type:'sub',amount:s.amount});
    });
    (calData.bills||[]).forEach(b=>tl.push({day:b.due_day,name:b.name,type:'bill',amount:b.amount}));
    tl.sort((a,b)=>a.day-b.day);
    const td_=today.getFullYear()===_calY&&today.getMonth()===_calM?today.getDate():-1;
    const tlEl=document.getElementById('cal-tl');if(!tlEl)return;
    tlEl.innerHTML=tl.length?`<div style="position:relative;padding-left:18px">
        <div style="position:absolute;left:5px;top:0;bottom:0;width:1px;background:var(--line2)"></div>
        ${tl.map(t=>`<div style="position:relative;padding:0 0 13px 15px">
            <div style="position:absolute;left:-5px;top:4px;width:7px;height:7px;border-radius:50%;background:var(--bg);border:2px solid ${t.day<td_?'var(--muted)':'var(--amber)'}"></div>
            <div style="font-family:var(--fm);font-size:10px;color:var(--muted);margin-bottom:2px">${mn[_calM]} ${ord(t.day)}</div>
            <div style="display:flex;align-items:center;gap:10px">
                <div style="font-size:13px;font-weight:600;color:var(--bright)">${t.name}</div>
                <div class="mono ${t.type==='sub'?'r':'am'}">${fmt(t.amount)}</div>
                <div class="mla"><span class="badge ${t.type==='sub'?'br-b':'ba'}">${t.type}</span></div>
            </div>
        </div>`).join('')}
    </div>`:`<div class="empty"><div class="ei">📅</div><p class="ep">No charges this month.</p></div>`;
}
})();
