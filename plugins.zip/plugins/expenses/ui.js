(function(){'use strict';

(function bp(){
    if(document.getElementById('exp-tb')) return;
    const d=document.createElement('div');d.id='page-expenses';d.className='page';
    d.innerHTML=`
    <div class="card">
        <div class="card-hd"><span class="card-title">Log Expense</span></div>
        <div class="fg-grid">
            <div class="fg"><label>Description</label><input id="exp-desc" type="text" placeholder="What did you buy?"></div>
            <div class="fg"><label>Amount $</label><input id="exp-amt" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Category</label><select id="exp-cat">
                <option>Food &amp; Dining</option><option>Transport / Gas</option><option>Shopping</option>
                <option>Entertainment</option><option>Health / Medical</option><option>Personal Care</option>
                <option>Home</option><option>Tech / Electronics</option><option>Tools / Hardware</option>
                <option>Pet Care</option><option>Other</option>
            </select></div>
            <div class="fg"><label>Date</label><div class="dw"><input id="exp-date" type="date"><button class="cal-btn" onclick="dp('exp-date')">📅</button></div></div>
            <div class="fg full"><div class="fa">
                <button class="btn btn-g btn-sm" onclick="exp_clear()">Clear</button>
                <button class="btn btn-p btn-sm" onclick="exp_save()">Log Expense</button>
            </div></div>
        </div>
    </div>
    <div class="card">
        <div class="card-hd">
            <span class="card-title">Expense Log</span>
            <div class="flex-c gap8">
                <select id="exp-mf" onchange="exp_render()" style="width:auto;font-size:12px;height:34px"></select>
                <span class="badge br-b" id="exp-badge"></span>
            </div>
        </div>
        <div class="tbl-wrap"><table>
            <thead><tr><th>Date</th><th>Description</th><th>Category</th><th>Amount</th><th></th></tr></thead>
            <tbody id="exp-tb"></tbody>
        </table></div>
    </div>`;
    const el=document.getElementById('page-expenses')||d;
    if(el===d&&!d.parentNode)document.getElementById('content').appendChild(d);
    document.getElementById('exp-date').value=ts();
})();

window.render_expenses=async function(){ exp_buildFilter(); exp_render(); };

window.exp_save=async function(){
    const body={
        desc:document.getElementById('exp-desc').value.trim(),
        amount:parseFloat(document.getElementById('exp-amt').value),
        category:document.getElementById('exp-cat').value,
        date:document.getElementById('exp-date').value||ts()
    };
    if(!body.desc||!body.amount){toast('Description and amount required','wn');return;}
    try{
        await api('POST','/api/mod/expenses/',body);
        toast('Logged','ok');exp_clear();
        await loadMod('expenses');exp_buildFilter();exp_render();
    }catch(e){toast(e.message,'er');}
};

window.exp_del=async function(id){
    if(!confirm('Delete this expense?'))return;
    try{
        await api('DELETE',`/api/mod/expenses/${id}`);
        toast('Deleted','ok');
        await loadMod('expenses');exp_render();
    }catch(e){toast(e.message,'er');}
};

window.exp_clear=function(){
    document.getElementById('exp-desc').value='';
    document.getElementById('exp-amt').value='';
    document.getElementById('exp-date').value=ts();
};

function exp_buildFilter(){
    const sel=document.getElementById('exp-mf');if(!sel)return;
    const cur=cmk();
    const months=[...new Set([...(DB.expenses||[]).map(e=>e.date?.slice(0,7)).filter(Boolean),cur])].sort().reverse();
    const prev=sel.value||cur;
    sel.innerHTML=months.map(m=>{
        const[y,mo]=m.split('-');
        const l=new Date(y,parseInt(mo)-1,1).toLocaleString('en-US',{month:'long',year:'numeric'});
        return`<option value="${m}"${m===prev?' selected':''}>${l}</option>`;
    }).join('');
}

function exp_render(){
    const month=document.getElementById('exp-mf')?.value||cmk();
    const expenses=(DB.expenses||[]).filter(e=>e.date?.startsWith(month)).sort((a,b)=>b.date.localeCompare(a.date));
    const total=expenses.reduce((s,e)=>s+parseFloat(e.amount),0);
    const badge=document.getElementById('exp-badge');
    if(badge)badge.textContent=`Total: ${fmt(total)}`;
    const tb=document.getElementById('exp-tb');if(!tb)return;
    if(!expenses.length){
        tb.innerHTML=`<tr><td colspan="5"><div class="empty"><div class="ei">🧾</div><p class="ep">No expenses this period.</p></div></td></tr>`;
        return;
    }
    tb.innerHTML=expenses.map(e=>`<tr>
        <td class="mono dm">${fd(e.date)}</td>
        <td>${e.desc}</td>
        <td><span class="badge" style="background:${cc(e.category)}22;color:${cc(e.category)}">${e.category}</span></td>
        <td class="mono r">${fmt(e.amount)}</td>
        <td><button class="btn btn-d btn-xs" onclick="exp_del('${e.id}')">🗑</button></td>
    </tr>`).join('');
}
})();
