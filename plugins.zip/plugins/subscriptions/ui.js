(function(){'use strict';

(function bp(){
    if(document.getElementById('sub-tb'))return;
    const d=document.createElement('div');d.id='page-subscriptions';d.className='page';
    d.innerHTML=`
    <div class="card">
        <div class="card-hd"><span class="card-title">Add / Edit Subscription</span><span class="badge br-b" id="sub-badge"></span></div>
        <div class="fg-grid">
            <input type="hidden" id="sub-eid">
            <div class="fg"><label>Service Name</label><input id="sub-name" type="text" placeholder="Netflix, Spotify..."></div>
            <div class="fg"><label>Amount $</label><input id="sub-amt" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Billing Cycle</label><select id="sub-cycle"><option value="weekly">Weekly</option><option value="monthly" selected>Monthly</option><option value="annual">Annual</option></select></div>
            <div class="fg"><label>Category</label><select id="sub-cat"><option>Entertainment</option><option>Software</option><option>Gaming</option><option>Music</option><option>Health</option><option>Cloud / Storage</option><option>News</option><option>Utilities</option><option>Other</option></select></div>
            <div class="fg"><label>Next Due Date</label><div class="dw"><input id="sub-due" type="date"><button class="cal-btn" onclick="dp('sub-due')">📅</button></div></div>
            <div class="fg full"><div class="fa">
                <button class="btn btn-g btn-sm" onclick="sub_clear()">Clear</button>
                <button class="btn btn-p btn-sm" onclick="sub_save()">Save Subscription</button>
            </div></div>
        </div>
    </div>
    <div class="card">
        <div class="card-hd"><span class="card-title">Active Subscriptions</span></div>
        <div class="tbl-wrap"><table>
            <thead><tr><th>Service</th><th>Category</th><th>Amount</th><th>Cycle</th><th>Monthly</th><th>Next Due</th><th>Active</th><th></th></tr></thead>
            <tbody id="sub-tb"></tbody>
        </table></div>
    </div>`;
    const pg=document.getElementById('page-subscriptions');
    if(pg&&!document.getElementById('sub-tb'))pg.innerHTML=d.innerHTML;
    else if(!pg)document.getElementById('content').appendChild(d);
})();

window.render_subscriptions=async function(){ sub_render(); };

window.sub_save=async function(){
    const id=document.getElementById('sub-eid').value;
    const body={name:document.getElementById('sub-name').value.trim(),amount:parseFloat(document.getElementById('sub-amt').value),cycle:document.getElementById('sub-cycle').value,category:document.getElementById('sub-cat').value,next_due:document.getElementById('sub-due').value,active:true};
    if(!body.name||!body.amount){toast('Name and amount required','wn');return;}
    try{
        if(id)await api('PUT',`/api/mod/subscriptions/${id}`,body);
        else await api('POST','/api/mod/subscriptions/',body);
        toast(id?'Updated':'Saved','ok');sub_clear();
        await loadMod('subscriptions');sub_render();
    }catch(e){toast(e.message,'er');}
};

window.sub_edit=function(id){
    const s=(DB.subscriptions||[]).find(x=>x.id===id);if(!s)return;
    document.getElementById('sub-eid').value=s.id;
    document.getElementById('sub-name').value=s.name;
    document.getElementById('sub-amt').value=s.amount;
    document.getElementById('sub-cycle').value=s.cycle;
    document.getElementById('sub-cat').value=s.category;
    document.getElementById('sub-due').value=s.next_due||'';
    document.getElementById('sub-name').focus();
};

window.sub_del=async function(id){
    if(!confirm('Delete this subscription?'))return;
    try{
        await api('DELETE',`/api/mod/subscriptions/${id}`);
        toast('Deleted','ok');await loadMod('subscriptions');sub_render();
    }catch(e){toast(e.message,'er');}
};

window.sub_toggle=async function(id){
    const s=(DB.subscriptions||[]).find(x=>x.id===id);if(!s)return;
    try{
        await api('PUT',`/api/mod/subscriptions/${id}`,{...s,active:!s.active});
        await loadMod('subscriptions');sub_render();
    }catch(e){toast(e.message,'er');}
};

window.sub_clear=function(){
    ['sub-eid','sub-name','sub-amt','sub-due'].forEach(id=>{const el=document.getElementById(id);if(el)el.value='';});
};

function sub_render(){
    const items=DB.subscriptions||[];
    const total=items.filter(s=>s.active).reduce((s,x)=>s+toMoSub(x.amount,x.cycle),0);
    const badge=document.getElementById('sub-badge');
    if(badge)badge.textContent=`${items.filter(s=>s.active).length} active — ${fmt(total)}/mo`;
    const tb=document.getElementById('sub-tb');if(!tb)return;
    if(!items.length){tb.innerHTML=`<tr><td colspan="8"><div class="empty"><div class="ei">🔄</div><p class="ep">No subscriptions yet.</p></div></td></tr>`;return;}
    tb.innerHTML=items.map(s=>{
        const mo=toMoSub(s.amount,s.cycle),d=du(s.next_due);
        return`<tr style="${s.active?'':'opacity:.35'}">
            <td class="br">${s.name}</td>
            <td><span class="badge" style="background:${cc(s.category)}22;color:${cc(s.category)}">${s.category}</span></td>
            <td class="mono">${fmt(s.amount)}</td>
            <td class="dm">${s.cycle}</td>
            <td class="mono ${s.active?'r':''}">${s.active?fmt(mo)+'/mo':'—'}</td>
            <td class="${d<=7&&d>=0?'am':d<0?'r':''}">${fd(s.next_due)}${d<=7&&d>=0?' ⚡':d<0?' ⚠':''}</td>
            <td><label class="toggle"><input type="checkbox" ${s.active?'checked':''} onchange="sub_toggle('${s.id}')"><div class="tgl-tr"></div><div class="tgl-th"></div></label></td>
            <td><div class="ra">
                <button class="btn btn-g btn-xs" onclick="sub_edit('${s.id}')">✏</button>
                <button class="btn btn-d btn-xs" onclick="sub_del('${s.id}')">🗑</button>
            </div></td>
        </tr>`;
    }).join('');
}
})();
