(function(){'use strict';

(function bp(){
    if(document.getElementById('bill-tb'))return;
    const d=document.createElement('div');d.id='page-bills';d.className='page';
    d.innerHTML=`
    <div class="card">
        <div class="card-hd"><span class="card-title">Add / Edit Bill</span><span class="badge ba" id="bill-badge"></span></div>
        <div class="fg-grid">
            <input type="hidden" id="bill-eid">
            <div class="fg"><label>Bill Name</label><input id="bill-name" type="text" placeholder="Rent, Electric..."></div>
            <div class="fg"><label>Amount $</label><input id="bill-amt" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Due Day of Month</label><input id="bill-due" type="number" placeholder="1-31" min="1" max="31"></div>
            <div class="fg"><label>Category</label><select id="bill-cat">
                <option>Housing</option><option>Utilities</option><option>Insurance</option>
                <option>Transport</option><option>Internet / Phone</option><option>Health</option>
                <option>Food</option><option>Other</option>
            </select></div>
            <div class="fg"><label>Autopay?</label><select id="bill-ap">
                <option value="false">No - Manual</option>
                <option value="true">Yes - Autopay</option>
            </select></div>
            <div class="fg"><label>Notes</label><input id="bill-notes" type="text" placeholder="Optional"></div>
            <div class="fg full"><div class="fa">
                <button class="btn btn-g btn-sm" onclick="bill_clear()">Clear</button>
                <button class="btn btn-p btn-sm" onclick="bill_save()">Save Bill</button>
            </div></div>
        </div>
    </div>
    <div class="card">
        <div class="card-hd"><span class="card-title">Recurring Bills</span></div>
        <div class="tbl-wrap"><table>
            <thead><tr><th>Bill</th><th>Category</th><th>Amount</th><th>Due Day</th><th>Next Due</th><th>Autopay</th><th>Notes</th><th></th></tr></thead>
            <tbody id="bill-tb"></tbody>
        </table></div>
    </div>`;
    const pg=document.getElementById('page-bills');
    if(pg&&!document.getElementById('bill-tb'))pg.innerHTML=d.innerHTML;
    else if(!pg)document.getElementById('content').appendChild(d);
})();

window.render_bills=async function(){ bill_render(); };

window.bill_save=async function(){
    const id=document.getElementById('bill-eid').value;
    const body={
        name:document.getElementById('bill-name').value.trim(),
        amount:parseFloat(document.getElementById('bill-amt').value),
        due_day:parseInt(document.getElementById('bill-due').value),
        category:document.getElementById('bill-cat').value,
        autopay:document.getElementById('bill-ap').value==='true',
        notes:document.getElementById('bill-notes').value.trim()
    };
    if(!body.name||!body.amount||!body.due_day){toast('Name, amount and due day required','wn');return;}
    try{
        if(id)await api('PUT',`/api/mod/bills/${id}`,body);
        else await api('POST','/api/mod/bills/',body);
        toast(id?'Updated':'Saved','ok');
        bill_clear();await loadMod('bills');bill_render();
    }catch(e){toast(e.message,'er');}
};

window.bill_edit=function(id){
    const r=(DB.bills||[]).find(x=>x.id===id);if(!r)return;
    document.getElementById('bill-eid').value=r.id;
    document.getElementById('bill-name').value=r.name;
    document.getElementById('bill-amt').value=r.amount;
    document.getElementById('bill-due').value=r.due_day;
    document.getElementById('bill-cat').value=r.category;
    document.getElementById('bill-ap').value=r.autopay?'true':'false';
    document.getElementById('bill-notes').value=r.notes||'';
    document.getElementById('bill-name').focus();
};

window.bill_del=async function(id){   // fixed: was 'rid' — now correctly 'id'
    if(!confirm('Delete this bill?'))return;
    try{
        await api('DELETE',`/api/mod/bills/${id}`);
        toast('Deleted','ok');await loadMod('bills');bill_render();
    }catch(e){toast(e.message,'er');}
};

window.bill_clear=function(){
    ['bill-eid','bill-name','bill-amt','bill-due','bill-notes'].forEach(id=>{
        const el=document.getElementById(id);if(el)el.value='';
    });
};

function bill_render(){
    const items=DB.bills||[];
    const total=items.reduce((s,b)=>s+parseFloat(b.amount),0);
    const badge=document.getElementById('bill-badge');
    if(badge)badge.textContent=`Monthly: ${fmt(total)}`;
    const tb=document.getElementById('bill-tb');if(!tb)return;
    if(!items.length){
        tb.innerHTML=`<tr><td colspan="8"><div class="empty"><div class="ei">📋</div><p class="ep">No bills configured yet.</p></div></td></tr>`;
        return;
    }
    tb.innerHTML=items.map(b=>{
        const nxt=nextBill(b.due_day),d=du(nxt);
        return`<tr>
            <td class="br">${b.name}</td>
            <td><span class="badge" style="background:${cc(b.category)}22;color:${cc(b.category)}">${b.category}</span></td>
            <td class="mono r">${fmt(b.amount)}</td>
            <td class="dm">${ord(b.due_day)}</td>
            <td class="${d<=7?'am':''}">${fd(nxt)}${d<=7?' ⚡':''}</td>
            <td>${b.autopay?'<span class="badge bg">Autopay</span>':'<span class="badge ba">Manual</span>'}</td>
            <td class="dm">${b.notes||'—'}</td>
            <td><div class="ra">
                <button class="btn btn-g btn-xs" onclick="bill_edit('${b.id}')">✏</button>
                <button class="btn btn-d btn-xs" onclick="bill_del('${b.id}')">🗑</button>
            </div></td>
        </tr>`;
    }).join('');
}
})();
