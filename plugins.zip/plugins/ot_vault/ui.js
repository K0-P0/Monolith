(function(){'use strict';

(function bp(){
    if(document.getElementById('otv-tb'))return;
    const div=document.createElement('div');div.id='page-ot_vault';div.className='page';
    div.innerHTML=`
    <div class="card">
        <div class="card-hd"><span class="card-title">⚡ Log Overtime Shift</span></div>
        <div class="fg-grid">
            <div class="fg"><label>Date</label><div class="dw"><input id="otv-date" type="date"><button class="cal-btn" onclick="dp('otv-date')">📅</button></div></div>
            <div class="fg"><label>OT Hours</label><input id="otv-hrs" type="number" step="0.5" oninput="otvault_preview()"></div>
            <div class="fg"><label>Base Pay $</label><input id="otv-rate" type="number" step="0.01" oninput="otvault_preview()"></div>
            <div class="fg"><label>Multiplier</label><input id="otv-mult" type="number" value="1.5" step="0.1" oninput="otvault_preview()"></div>
            <div class="fg"><label>Est. Tax %</label><input id="otv-tax" type="number" value="17" step="0.5" oninput="otvault_preview()"></div>
            <div class="fg full"><div id="otv-prev"></div></div>
            <div class="fg full"><div class="fa">
                <button class="btn btn-g btn-sm" onclick="otvault_clear()">Clear</button>
                <button class="btn btn-p btn-sm" onclick="otvault_save()">Save OT Shift</button>
            </div></div>
        </div>
    </div>
    <div class="card">
        <div class="card-hd"><span class="card-title">OT History</span></div>
        <div class="tbl-wrap"><table>
            <thead><tr><th>Date</th><th>Hours</th><th>Gross</th><th>Tax</th><th>Net</th><th></th></tr></thead>
            <tbody id="otv-tb"></tbody>
        </table></div>
    </div>`;
    document.getElementById('content').appendChild(div);
    document.getElementById('otv-date').value=ts();
})();

window.dashWidget_ot_vault=function(){
    const items=DB['ot_vault']||[];
    const monthKey=cmk();
    const moNet=items.filter(i=>i.date&&i.date.startsWith(monthKey)).reduce((s,i)=>s+parseFloat(i.net||0),0);
    return`<div class="card" onclick="navigate('ot_vault')" style="cursor:pointer">
        <div class="card-hd"><span class="card-title">⚡ OT Pay (This Month)</span></div>
        <div class="stat-row"><div class="stat">
            <div class="stat-label">Net Take-Home</div>
            <div class="stat-val g">${fmt(moNet)}</div>
            <div class="stat-bar o"></div>
        </div></div>
    </div>`;
};

window.ot_vault_get_monthly_total=function(){
    const items=DB['ot_vault']||[];
    const monthKey=cmk();
    return items.filter(i=>i.date&&i.date.startsWith(monthKey)).reduce((sum,i)=>sum+parseFloat(i.net||0),0);
};

window.render_ot_vault=async function(){
    const items=(DB['ot_vault']||[]).sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    const tb=document.getElementById('otv-tb');if(!tb)return;
    if(!items.length){tb.innerHTML='<tr><td colspan="6"><div class="empty"><div class="ei">⚡</div><p class="ep">No OT shifts logged yet.</p></div></td></tr>';return;}
    tb.innerHTML=items.map(i=>`<tr>
        <td class="mono dm">${fd(i.date)}</td>
        <td>${i.hours}h @ ${i.multiplier}x</td>
        <td class="mono am">${fmt(i.gross)}</td>
        <td class="mono r">-${fmt(i.tax_amt)}</td>
        <td class="mono g br">${fmt(i.net)}</td>
        <td><button class="btn btn-d btn-xs" onclick="otvault_del('${i.id}')">🗑</button></td>
    </tr>`).join('');
};

window.otvault_preview=function(){
    const h=parseFloat(document.getElementById('otv-hrs').value)||0;
    const r=parseFloat(document.getElementById('otv-rate').value)||0;
    const m=parseFloat(document.getElementById('otv-mult').value)||1.5;
    const t=parseFloat(document.getElementById('otv-tax').value)||17;
    const gross=h*(r*m),net=gross-(gross*(t/100));
    const prev=document.getElementById('otv-prev');
    if(prev)prev.innerHTML=gross>0?`<div class="alert al-s">Preview: <b>${fmt(gross)} Gross</b> → <b class="g">${fmt(net)} Net</b></div>`:'';
};

window.otvault_save=async function(){
    const body={date:document.getElementById('otv-date').value,hours:document.getElementById('otv-hrs').value,rate:document.getElementById('otv-rate').value,multiplier:document.getElementById('otv-mult').value,tax_rate:document.getElementById('otv-tax').value};
    if(!body.hours){toast('Hours required','wn');return;}
    try{
        await api('POST','/api/mod/ot_vault/',body);
        toast('OT Saved','ok');otvault_clear();
        await loadMod('ot_vault');
        await renderDashboard();   // fixed: added await
        await render_ot_vault();  // fixed: added await
    }catch(e){toast(e.message,'er');}
};

window.otvault_del=async function(id){
    if(!confirm('Delete this shift?'))return;
    try{
        await api('DELETE',`/api/mod/ot_vault/${id}`);
        await loadMod('ot_vault');
        await renderDashboard();   // fixed: added await
        await render_ot_vault();  // fixed: added await
    }catch(e){toast(e.message,'er');}
};

window.otvault_clear=function(){
    const h=document.getElementById('otv-hrs');if(h)h.value='';
    const r=document.getElementById('otv-rate');if(r)r.value='';
    const p=document.getElementById('otv-prev');if(p)p.innerHTML='';
};
})();
