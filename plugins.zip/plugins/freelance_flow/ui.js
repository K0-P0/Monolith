(function(){'use strict';
const FF_ID='freelance_flow';
const STATUSES=['Lead','In Progress','Invoiced','Partial','Paid','Archived'];

const ffNum=v=>isFinite(parseFloat(v))?parseFloat(v):0;
const ffNet=j=>Math.max(0,ffNum(j.amount_received)-ffNum(j.expenses)-ffNum(j.tax_set_aside));
const ffOut=j=>Math.max(0,ffNum(j.quote_amount)-ffNum(j.amount_received));
function ffOverdue(j){
    if(j.status==='Paid'||j.status==='Archived'||!j.due_date)return false;
    return ffOut(j)>0&&du(j.due_date)<0;
}
function ffBadgeCls(j){
    if(ffOverdue(j))return'br-b';
    if(j.status==='Paid')return'bg';
    if(j.status==='In Progress')return'bb';
    if(j.status==='Invoiced')return'ba';
    return'bgr';
}

(function bp(){
    if(document.getElementById('ff-list'))return;
    const d=document.createElement('div');d.id='page-freelance_flow';d.className='page';
    d.innerHTML=`
    <div class="card">
        <div class="card-hd"><span class="card-title">💼 Add / Edit Job</span><span class="badge bgr" id="ff-badge"></span></div>
        <input type="hidden" id="ff-eid">
        <div class="fg-grid">
            <div class="fg"><label>Job Title</label><input id="ff-title" type="text" placeholder="Website redesign..."></div>
            <div class="fg"><label>Client</label><input id="ff-client" type="text" placeholder="Client name..."></div>
            <div class="fg"><label>Status</label><select id="ff-status">${STATUSES.map(s=>`<option>${s}</option>`).join('')}</select></div>
            <div class="fg"><label>Quote Amount $</label><input id="ff-quote" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Amount Received $</label><input id="ff-recv" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Expenses $</label><input id="ff-exp" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Tax Set Aside $</label><input id="ff-tax" type="number" placeholder="0.00" step="0.01" min="0"></div>
            <div class="fg"><label>Invoice Date</label><div class="dw"><input id="ff-idate" type="date"><button class="cal-btn" onclick="dp('ff-idate')">📅</button></div></div>
            <div class="fg"><label>Due Date</label><div class="dw"><input id="ff-ddate" type="date"><button class="cal-btn" onclick="dp('ff-ddate')">📅</button></div></div>
            <div class="fg"><label>Paid Date</label><div class="dw"><input id="ff-pdate" type="date"><button class="cal-btn" onclick="dp('ff-pdate')">📅</button></div></div>
            <div class="fg full"><label>Notes</label><input id="ff-notes" type="text" placeholder="Optional"></div>
            <div class="fg full"><div class="fa">
                <button class="btn btn-g btn-sm" onclick="ff_clear()">Clear</button>
                <button class="btn btn-p btn-sm" onclick="ff_save()">Save Job</button>
            </div></div>
        </div>
    </div>
    <div class="stat-row" id="ff-stats"></div>
    <div class="card">
        <div class="card-hd">
            <span class="card-title">Job Board</span>
            <div class="flex-c gap8">
                <input id="ff-search" type="text" placeholder="Search..." oninput="ff_render()" style="height:34px;font-size:12px;width:140px">
                <select id="ff-filter" onchange="ff_render()" style="height:34px;font-size:12px;width:auto">
                    <option value="">All Statuses</option>
                    ${STATUSES.map(s=>`<option>${s}</option>`).join('')}
                </select>
            </div>
        </div>
        <div id="ff-list"></div>
    </div>`;
    const pg=document.getElementById('page-freelance_flow');
    if(pg&&!document.getElementById('ff-list'))pg.innerHTML=d.innerHTML;
    else if(!pg)document.getElementById('content').appendChild(d);
})();

window.dashWidget_freelance_flow=function(){
    const items=DB[FF_ID]||[];
    const overdue=items.filter(ffOverdue).length;
    const monthNet=items.filter(j=>(j.paid_date||'').startsWith(cmk())).reduce((s,j)=>s+ffNet(j),0);
    const wait=items.filter(j=>j.status!=='Paid'&&j.status!=='Archived').reduce((s,j)=>s+ffOut(j),0);
    return`<div class="card" onclick="navigate('freelance_flow')" style="cursor:pointer">
        <div class="card-hd">
            <span class="card-title">💼 Freelance Flow</span>
            <span class="badge ${overdue>0?'br-b':'bgr'}">${overdue>0?overdue+' overdue':items.length+' jobs'}</span>
        </div>
        <div class="stat-row" style="grid-template-columns:1fr 1fr;gap:8px">
            <div class="stat"><div class="stat-label">Month Net</div><div class="stat-val g">${fmtK(monthNet)}</div><div class="stat-bar g"></div></div>
            <div class="stat"><div class="stat-label">Outstanding</div><div class="stat-val am">${fmtK(wait)}</div><div class="stat-bar o"></div></div>
        </div>
    </div>`;
};

window.freelance_flow_get_monthly_total=function(){
    return(DB[FF_ID]||[]).filter(j=>(j.paid_date||'').startsWith(cmk())).reduce((s,j)=>s+ffNet(j),0);
};

window.render_freelance_flow=async function(){
    const items=DB[FF_ID]||[];
    const active=items.filter(j=>j.status!=='Archived');
    const totalNet=active.reduce((s,j)=>s+ffNet(j),0);
    const totalOut=active.reduce((s,j)=>s+ffOut(j),0);
    const overdue=active.filter(ffOverdue).length;
    const badge=document.getElementById('ff-badge');
    if(badge)badge.textContent=`${active.length} active`;
    const stats=document.getElementById('ff-stats');
    if(stats)stats.innerHTML=`
        <div class="stat"><div class="stat-label">Active Jobs</div><div class="stat-val">${active.length}</div><div class="stat-bar b"></div></div>
        <div class="stat"><div class="stat-label">Net Earned</div><div class="stat-val g">${fmtK(totalNet)}</div><div class="stat-bar g"></div></div>
        <div class="stat"><div class="stat-label">Outstanding</div><div class="stat-val am">${fmtK(totalOut)}</div><div class="stat-bar o"></div></div>
        <div class="stat"><div class="stat-label">Overdue</div><div class="stat-val ${overdue>0?'r':''}">${overdue}</div><div class="stat-bar ${overdue>0?'r':''}"></div></div>`;
    ff_render();
};

function ff_render(){
    const items=DB[FF_ID]||[];
    const q=(document.getElementById('ff-search')?.value||'').toLowerCase();
    const sf=document.getElementById('ff-filter')?.value||'';
    const list=document.getElementById('ff-list');if(!list)return;
    let rows=items.filter(j=>{
        const matchQ=!q||(j.title+' '+j.client).toLowerCase().includes(q);
        const matchS=!sf||j.status===sf;
        return matchQ&&matchS;
    }).sort((a,b)=>{
        if(ffOverdue(a)&&!ffOverdue(b))return-1;
        if(!ffOverdue(a)&&ffOverdue(b))return 1;
        return(b.created||'').localeCompare(a.created||'');
    });
    if(!rows.length){list.innerHTML=`<div class="empty"><div class="ei">💼</div><p class="ep">No jobs found.</p></div>`;return;}
    list.innerHTML=rows.map(j=>`
    <div class="card" style="margin-bottom:12px${ffOverdue(j)?';border-left:3px solid var(--red)':''}">
        <div class="card-hd">
            <div>
                <div class="br">${j.title}</div>
                <div class="dm" style="font-size:11px;margin-top:2px">${j.client||'—'}</div>
            </div>
            <div class="flex-c gap8 mla">
                <span class="badge ${ffBadgeCls(j)}">${ffOverdue(j)?'Overdue':j.status}</span>
                <button class="btn btn-g btn-xs" onclick="ff_edit('${j.id}')">✏</button>
                <button class="btn btn-d btn-xs" onclick="ff_del('${j.id}')">🗑</button>
            </div>
        </div>
        <div class="stat-row" style="grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px;margin-top:10px">
            <div class="stat"><div class="stat-label">Net Take-Home</div><div class="stat-val g">${fmt(ffNet(j))}</div></div>
            <div class="stat"><div class="stat-label">Outstanding</div><div class="stat-val ${ffOut(j)>0?'am':''}">${fmt(ffOut(j))}</div></div>
            <div class="stat"><div class="stat-label">Quote</div><div class="stat-val">${fmt(j.quote_amount)}</div></div>
            ${j.due_date?`<div class="stat"><div class="stat-label">Due</div><div class="stat-val ${du(j.due_date)<0?'r':du(j.due_date)<=7?'am':''}" style="font-size:13px">${fd(j.due_date)}</div></div>`:''}
        </div>
        ${j.notes?`<div class="dm" style="font-size:11px;margin-top:8px">${j.notes}</div>`:''}
    </div>`).join('');
}

window.ff_save=async function(){
    const id=document.getElementById('ff-eid').value;
    const body={
        title:document.getElementById('ff-title').value.trim(),
        client:document.getElementById('ff-client').value.trim(),
        status:document.getElementById('ff-status').value,
        quote_amount:parseFloat(document.getElementById('ff-quote').value)||0,
        amount_received:parseFloat(document.getElementById('ff-recv').value)||0,
        expenses:parseFloat(document.getElementById('ff-exp').value)||0,
        tax_set_aside:parseFloat(document.getElementById('ff-tax').value)||0,
        invoice_date:document.getElementById('ff-idate').value,
        due_date:document.getElementById('ff-ddate').value,
        paid_date:document.getElementById('ff-pdate').value,
        notes:document.getElementById('ff-notes').value.trim(),
    };
    if(!body.title){toast('Job title required','wn');return;}
    try{
        if(id)await api('PUT',`/api/mod/freelance_flow/${id}`,body);
        else await api('POST','/api/mod/freelance_flow/',body);
        toast(id?'Updated':'Job saved','ok');ff_clear();
        await loadMod(FF_ID);await render_freelance_flow();
    }catch(e){toast(e.message,'er');}
};

window.ff_edit=function(id){
    const j=(DB[FF_ID]||[]).find(x=>x.id===id);if(!j)return;
    document.getElementById('ff-eid').value=j.id;
    document.getElementById('ff-title').value=j.title||'';
    document.getElementById('ff-client').value=j.client||'';
    document.getElementById('ff-status').value=j.status||'Lead';
    document.getElementById('ff-quote').value=j.quote_amount||'';
    document.getElementById('ff-recv').value=j.amount_received||'';
    document.getElementById('ff-exp').value=j.expenses||'';
    document.getElementById('ff-tax').value=j.tax_set_aside||'';
    document.getElementById('ff-idate').value=j.invoice_date||'';
    document.getElementById('ff-ddate').value=j.due_date||'';
    document.getElementById('ff-pdate').value=j.paid_date||'';
    document.getElementById('ff-notes').value=j.notes||'';
    document.getElementById('ff-title').scrollIntoView({behavior:'smooth'});
};

window.ff_del=async function(id){
    if(!confirm('Delete this job?'))return;
    try{
        await api('DELETE',`/api/mod/freelance_flow/${id}`);
        toast('Deleted','ok');await loadMod(FF_ID);await render_freelance_flow();
    }catch(e){toast(e.message,'er');}
};

window.ff_clear=function(){
    ['ff-eid','ff-title','ff-client','ff-quote','ff-recv','ff-exp','ff-tax','ff-idate','ff-ddate','ff-pdate','ff-notes'].forEach(id=>{
        const el=document.getElementById(id);if(el)el.value='';
    });
    const s=document.getElementById('ff-status');if(s)s.value='Lead';
};
})();
